const inputBox = document.getElementById("val");
const listContainer = document.getElementById("listItem");
function addTask()
{
    if(inputBox.value ==='')
      alert("You Must Write Something! ");
    else
    {
        let li =  document.createElement("li");
        li.innerHTML = inputBox.value;
        listItem.appendChild(li);
        let span = document.createElement("span");
        span.innerHTML = "\u00d7";
        li.appendChild(span);
        saveMyData();
    }
    inputBox = "";
}
listContainer.addEventListener('click',function(e)
{
    if(e.target.tagName ==="LI")
    {
       e.target.classList.toggle("checked");
       saveMyData();
    }
    else if(e.target.tagName ==="SPAN")
    {
        e.target.parentElement.remove();
       saveMyData();
    }
},false)
function saveMyData()
{
    localStorage.setItem("data",listContainer.innerHTML);
}
function showData()
{
    listContainer.innerHTML = localStorage.getItem("data");
}
showData();